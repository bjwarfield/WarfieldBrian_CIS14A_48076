	/*
	Brian Warfield
	CIS 12 PHP
	8 Oct 2014
	Purpose: Lab Codecademy JavaScript Lesson 9: More Control Flow in JS
	*/
// Declare your variables here!
var programming = false;

var happy = function() {
  // Add your if/else statement here!
  if (!programming){
    return true;
  }else{
      return false;
  }
};