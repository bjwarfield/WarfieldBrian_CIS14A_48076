	/*
	Brian Warfield
	CIS 12 PHP
	1 Oct 2014
	Purpose: Lab Codecademy JavaScript Lesson 7:Introduction to 'While' Loops in JS
	*/
// Ask a question on the Q&A Forum if you get stuck!
// Write your code below!
for (var i = 0; i < 11; i++){
    console.log(i);
}
var j = 0;
while (j < 11){
    console.log(j);
    j++;
}
k = 50;
do{
    console.log(k);
}while(k < 11);