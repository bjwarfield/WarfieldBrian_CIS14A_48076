	/*
	Brian Warfield
	CIS 12 PHP
	15 Oct 2014
	Purpose: Lab Codecademy JavaScript Lesson 11: Arrays and Objects i nJS
	*/
var object1 = new Object();
var object2 = new Object();
var object3 = new Object();
object1.what = "Bacon";
object2.what = "Chicken";
object3.what = "Salad";
object1.tasty = true;
object2.tasty = true;
object3.tasty = false;