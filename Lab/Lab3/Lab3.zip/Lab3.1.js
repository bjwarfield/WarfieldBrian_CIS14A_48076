	/*
	Brian Warfield
	CIS 12 PHP
	DATE
	Purpose: Lab Codecademy JavaScript Lesson 5: Introduction to For Loops
	*/
// Ask a question on the Q&A Forum if you get stuck!
var names = ["Jacob", "Jackson", "Jeremy", "Jason", "Jamariquai"];

for (var i = 0; i< names.length; i++){
    console.log("I know someone called " + names[i]);
}